        clear all
        [clean fs]= wavread('sentence1.wav');
        s1_clean=clean(:,1);
        s2_clean=s1_clean;
        delay=19;
        f=800;
        %n1=filter(1,[1],sqrt(.108)*randn(length(s1_clean),1));
        [noise fs]= wavread('crowd.wav');
        n1=1.85*noise(1:length(s1_clean),1);
        %n1=.464*sin(2*pi*f*(1:length(s1_clean))/fs)';
        n2=[zeros(delay,1);n1(1:length(s1_clean)-delay,1)];
        M1= s1_clean+n1;
        M2= s2_clean+n2;
        M1_clean= s1_clean;
        M2_clean= s2_clean;
        x = M1-M2;                   % Input
        d1 = M1+M2;                  % Desired signal (AR signal)
        x_clean=M1_clean-M2_clean;
        d1_clean=M1_clean+M2_clean;
        mu = 0.002;               % Step size
        h = adaptfilt.lms(40,mu);   % 2 tap sign-data adaptive filter
        [y1_clean,e1_clean]=filter(h,x_clean,d1_clean);         % Estimate and error
        [y1,e1]=filter(h,x,d1);         % Estimate and error      
    	SNR_DA=10*log10(var(e1_clean)/(var(d1-d1_clean)))
        SNR_BF=10*log10(var(e1_clean)/(var(e1-e1_clean)))
        SNR_Base=10*log10(var(s1_clean)/(var(n1)))
        
        wavwrite(M1/max(abs(M1)),fs,16,'matlab_crowd_base.wav');
        wavwrite(d1/max(abs(d1)),fs,16,'matlab_crowd_delayadd.wav');
        wavwrite(e1/max(abs(e1)),fs,16,'matlab_crowd_beamforming.wav');